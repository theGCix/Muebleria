import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface Product {
  id: string;
  nombre: string;
  descripcion: string | null;
  sku: string | null;
  precio: number;
  stock: number | null;
  categoria: string | null;
  subcategoria: string | null;
  material_base: string | null;
  imagen_url: string | null;
  imagen_public_id: string | null;
  created_at: string;
  descuento_porcentaje: number | null;
  oferta_vence_el: string | null;
}

export type ProductSort = "recientes" | "precio_asc" | "precio_desc";

export function useProducts(first = 12, search?: string) {
  return useQuery({
    queryKey: ["products-public", first, search ?? null],
    queryFn: async () => {
      let q = supabase
        .from("products")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(first);
      if (search) {
        q = q.or(`nombre.ilike.%${search}%,categoria.ilike.%${search}%`);
      }
      const { data, error } = await q;
      if (error) throw new Error(error.message);
      return (data ?? []) as Product[];
    },
  });
}

interface CategoryQuery {
  categoria: string;
  subcategoria?: string;
  materialBase?: string;
  sort?: ProductSort;
}

/**
 * Productos de una categoría (y opcionalmente subcategoría / material_base),
 * usados por la página /categoria/$slug.
 * Equivale a: SELECT * FROM products WHERE categoria = ... [AND subcategoria = ...] [AND material_base = ...]
 */
export function useProductsByCategory({ categoria, subcategoria, materialBase, sort = "recientes" }: CategoryQuery) {
  return useQuery({
    queryKey: ["products-by-category", categoria, subcategoria ?? null, materialBase ?? null, sort],
    queryFn: async () => {
      let q = supabase.from("products").select("*").eq("categoria", categoria);
      if (subcategoria) q = q.eq("subcategoria", subcategoria);
      if (materialBase) q = q.eq("material_base", materialBase);

      if (sort === "precio_asc") q = q.order("precio", { ascending: true });
      else if (sort === "precio_desc") q = q.order("precio", { ascending: false });
      else q = q.order("created_at", { ascending: false });

      const { data, error } = await q;
      if (error) throw new Error(error.message);
      return (data ?? []) as Product[];
    },
  });
}

/**
 * Trae solo las columnas necesarias para calcular cuántos productos hay
 * por cada subcategoría / material_base dentro de una categoría — usado
 * para mostrar los contadores en los chips de filtro sin duplicar queries.
 */
export function useCategoryFacets(categoria: string) {
  return useQuery({
    queryKey: ["products-category-facets", categoria],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("subcategoria, material_base")
        .eq("categoria", categoria);
      if (error) throw new Error(error.message);
      return (data ?? []) as Pick<Product, "subcategoria" | "material_base">[];
    },
  });
}

/**
 * Productos con oferta activa (descuento_porcentaje > 0 y sin vencer) —
 * usado por OfertasSection en el home. El criterio de "activa" debe
 * coincidir con lib/pricing.ts#ofertaInfo.
 */
export function useOfertas(first = 8) {
  return useQuery({
    queryKey: ["products-ofertas", first],
    queryFn: async () => {
      const nowIso = new Date().toISOString();
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("activo", true)
        .gt("descuento_porcentaje", 0)
        .or(`oferta_vence_el.is.null,oferta_vence_el.gt.${nowIso}`)
        .order("descuento_porcentaje", { ascending: false })
        .limit(first);
      if (error) throw new Error(error.message);
      return (data ?? []) as Product[];
    },
  });
}

export function useProduct(id: string) {
  return useQuery({
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*")
        .eq("id", id)
        .single();
      if (error) throw new Error(error.message);
      return data as Product;
    },
    enabled: !!id,
  });
}

const PAGE_SIZE = 16;

interface AllProductsQuery {
  search?: string;
  categoria?: string; // slug de CATEGORIAS, o undefined = todas
  sort?: ProductSort;
  page: number; // 0-indexed
}

/**
 * Catálogo completo con paginación — usado por /catalogo.
 * A diferencia de useProducts (preview acotado del home), esta trae
 * el conteo total para poder mostrar "Cargar más" con precisión.
 */
export function useAllProducts({ search, categoria, sort = "recientes", page }: AllProductsQuery) {
  return useQuery({
    queryKey: ["products-all", search ?? null, categoria ?? null, sort, page],
    queryFn: async () => {
      let q = supabase
        .from("products")
        .select("*", { count: "exact" })
        .eq("activo", true);

      if (categoria) q = q.eq("categoria", categoria);
      if (search) q = q.or(`nombre.ilike.%${search}%,descripcion.ilike.%${search}%`);

      if (sort === "precio_asc") q = q.order("precio", { ascending: true });
      else if (sort === "precio_desc") q = q.order("precio", { ascending: false });
      else q = q.order("created_at", { ascending: false });

      const from = page * PAGE_SIZE;
      const { data, error, count } = await q.range(from, from + PAGE_SIZE - 1);
      if (error) throw new Error(error.message);
      return { products: (data ?? []) as Product[], total: count ?? 0 };
    },
  });
}

/**
 * Conteo de productos por categoría, para mostrar en los chips de filtro
 * de /catalogo sin disparar una query por categoría.
 */
export function useProductCountsByCategory() {
  return useQuery({
    queryKey: ["products-counts-by-category"],
    queryFn: async () => {
      const { data, error } = await supabase.from("products").select("categoria").eq("activo", true);
      if (error) throw new Error(error.message);
      const counts: Record<string, number> = {};
      for (const row of data ?? []) {
        const c = (row as { categoria: string | null }).categoria;
        if (c) counts[c] = (counts[c] ?? 0) + 1;
      }
      return counts;
    },
  });
}