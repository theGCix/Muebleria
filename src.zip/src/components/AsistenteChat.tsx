// src/components/AsistenteChat.tsx
import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Loader2, Sparkles } from "lucide-react";
import { API_URL as API } from "@/config";
import { ORIGEN_ENVIO } from "@/lib/envios";
import { useCartStore } from "@/stores/cartStore";
import { toast } from "sonner";

type Message = { role: "user" | "assistant"; content: string };
type CartAction = {
  id: string; title: string; price: number;
  image?: string; sku?: string; cantidad: number;
};

// ── Preguntas frecuentes: respuesta instantánea, sin costo de IA ──
const PREGUNTAS_RAPIDAS: { label: string; pregunta: string; respuesta: string }[] = [
  {
    label: "🚚 ¿Cómo es el envío?",
    pregunta: "¿Cómo es el envío?",
    respuesta: `Hacemos envío a domicilio en Lima y Callao — el costo depende de tu distrito y se calcula automáticamente en el checkout. También puedes elegir "Recojo en tienda" sin costo, en nuestra tienda de ${ORIGEN_ENVIO}. Si un producto no está en stock, te avisamos la fecha estimada antes de pagar, así que nunca hay sorpresas.`,
  },
  {
    label: "🛡️ ¿Qué garantía tienen?",
    pregunta: "¿Qué garantía tienen?",
    respuesta: "Todos nuestros muebles tienen 2 años de garantía en estructura. Si notas algún defecto de fabricación dentro de ese periodo, lo reparamos o reponemos sin costo.",
  },
  {
    label: "💳 ¿Cómo puedo pagar?",
    pregunta: "¿Cómo puedo pagar?",
    respuesta: "Aceptamos tarjetas de crédito y débito (Visa, Mastercard, Amex) mediante Niubiz, con pago 100% seguro y encriptado. Aún no manejamos pago contraentrega ni transferencia directa.",
  },
  {
    label: "📦 Consultar mi pedido",
    pregunta: "Quiero consultar el estado de mi pedido",
    respuesta: null, // este sí necesita la IA (requiere número + correo)
  },
  {
    label: "💬 Tengo otra pregunta",
    pregunta: "",
    respuesta: null, // traspaso directo a la IA, sin pregunta fija
  },
];

async function chatWithAssistant(messages: Message[], sessionId: string): Promise<{ reply: string; cartActions: CartAction[] }> {
  const res = await fetch(`${API}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, sessionId }),
  });
  if (!res.ok) throw new Error("Error al conectar con el asistente");
  const data = await res.json();
  return { reply: data.reply ?? "Lo siento, no pude procesar tu consulta.", cartActions: data.cartActions ?? [] };
}

type ChatResult = { reply: string; cartActions: CartAction[] };
type StreamHandlers = {
  onToken: (t: string) => void;
  onStatus: (t: string) => void;
  onReset: () => void;
};

/** El backend no tiene /api/chat/stream (versión anterior): se usa el modo sin streaming. */
class StreamNoDisponible extends Error {}

// Lee la respuesta por Server-Sent Events: status · token · reset · done · error
async function chatWithAssistantStream(
  messages: Message[],
  sessionId: string,
  h: StreamHandlers,
  signal?: AbortSignal,
): Promise<ChatResult> {
  const res = await fetch(`${API}/api/chat/stream`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages, sessionId }),
    signal,
  });
  if (res.status === 404) throw new StreamNoDisponible();
  if (!res.ok || !res.body) throw new Error("Error al conectar con el asistente");

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let result: ChatResult | null = null;

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let sep: number;
    while ((sep = buffer.indexOf("\n\n")) !== -1) {
      const raw = buffer.slice(0, sep);
      buffer = buffer.slice(sep + 2);

      let event = "message";
      let data = "";
      for (const line of raw.split("\n")) {
        if (line.startsWith("event:")) event = line.slice(6).trim();
        else if (line.startsWith("data:")) data += line.slice(5).trim();
      }
      const payload = data ? JSON.parse(data) : {};

      if (event === "token") h.onToken(payload.text ?? "");
      else if (event === "status") h.onStatus(payload.text ?? "");
      else if (event === "reset") h.onReset();
      else if (event === "error") throw new Error(payload.error ?? "Error del asistente");
      else if (event === "done") {
        result = {
          reply: payload.reply ?? "Lo siento, no pude procesar tu consulta.",
          cartActions: payload.cartActions ?? [],
        };
      }
    }
  }
  if (!result) throw new Error("Respuesta incompleta del asistente");
  return result;
}

export function AsistenteChat() {
  const [open, setOpen]       = useState(false);
  const [input, setInput]     = useState("");
  const [loading, setLoading] = useState(false);
  const [estado, setEstado]   = useState("Pensando…");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "assistant",
      content: "¡Hola! Soy el asistente de G&M Mueblería. Puedo ayudarte a encontrar el mueble ideal, revisar precios y stock, agregar productos a tu carrito, o consultar el estado de un pedido. ¿En qué te ayudo?",
    },
  ]);
  const bottomRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  // Id de la conversación (se guarda en Supabase para analítica); se renueva al recargar la página
  const sessionIdRef = useRef<string>(crypto.randomUUID());
  const addItem = useCartStore((s) => s.addItem);
  const updateQty = useCartStore((s) => s.updateQty);
  const items = useCartStore((s) => s.items);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, estado]);

  // Si el componente se desmonta, cancelamos la generación en curso
  useEffect(() => () => abortRef.current?.abort(), []);

  const aplicarAccionesCarrito = (acciones: CartAction[]) => {
    for (const a of acciones) {
      addItem({ id: a.id, title: a.title, price: a.price, image: a.image, sku: a.sku });
      const cantidad = a.cantidad ?? 1;
      if (cantidad > 1) {
        const previa = items.find((i) => i.id === a.id)?.qty ?? 0;
        updateQty(a.id, previa + cantidad);
      }
      toast.success(`"${a.title}" agregado al carrito desde el asistente`);
    }
  };

  const enviarPreguntaRapida = (item: typeof PREGUNTAS_RAPIDAS[number]) => {
    if (loading) return;
    if (item.respuesta) {
      // Respuesta fija: no gasta tokens de IA, aparece al toque
      setMessages((m) => [
        ...m,
        { role: "user", content: item.pregunta },
        { role: "assistant", content: item.respuesta! },
      ]);
    } else if (item.pregunta) {
      // Necesita datos reales (ej. consultar pedido): va por la IA
      setInput(item.pregunta);
    } else {
      // Traspaso libre: le avisamos al cliente que pasa a la IA, sin asumir la pregunta
      setMessages((m) => [
        ...m,
        { role: "assistant", content: "Claro, cuéntame qué necesitas y te ayudo con eso." },
      ]);
    }
  };

  // Reemplaza el contenido del último mensaje (el que se está "escribiendo")
  const editarUltimo = (fn: (prev: string) => string) =>
    setMessages((m) => {
      const copia = [...m];
      const last = copia[copia.length - 1];
      copia[copia.length - 1] = { ...last, content: fn(last.content) };
      return copia;
    });

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput("");

    const newMessages: Message[] = [...messages, { role: "user", content: text }];
    // Burbuja vacía del asistente que se irá llenando con el stream
    setMessages([...newMessages, { role: "assistant", content: "" }]);
    setEstado("Pensando…");
    setLoading(true);

    const abort = new AbortController();
    abortRef.current = abort;

    try {
      let result: ChatResult;
      try {
        result = await chatWithAssistantStream(
          newMessages,
          sessionIdRef.current,
          {
            onToken: (t) => editarUltimo((prev) => prev + t),
            onStatus: (t) => setEstado(t),
            onReset: () => editarUltimo(() => ""),
          },
          abort.signal,
        );
      } catch (e) {
        if (!(e instanceof StreamNoDisponible)) throw e;
        result = await chatWithAssistant(newMessages, sessionIdRef.current); // backend sin streaming
      }

      editarUltimo(() => result.reply);
      if (result.cartActions.length > 0) aplicarAccionesCarrito(result.cartActions);
    } catch (e) {
      if ((e as Error).name === "AbortError") return;
      editarUltimo(() => "Disculpa, hubo un error. Por favor intenta de nuevo.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {/* Botón flotante */}
      <button
        onClick={() => setOpen((o) => !o)}
        className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-xl flex items-center justify-center transition-transform hover:scale-105 active:scale-95"
        style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
        aria-label="Asistente de compra"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
      </button>

      {/* Panel de chat */}
      {open && (
        <div
          className="fixed bottom-24 right-4 z-50 rounded-2xl shadow-2xl border overflow-hidden flex flex-col"
          style={{
            background: "var(--background)",
            borderColor: "var(--border)",
            maxHeight: "70vh",
            width: "min(340px, calc(100vw - 2rem))",
          }}
        >
          {/* Header */}
          <div
            className="px-4 py-3 flex items-center gap-2.5"
            style={{ background: "var(--primary)", color: "var(--primary-foreground)" }}
          >
            <Sparkles className="h-4 w-4 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold leading-none">Asistente G&M</p>
              <p className="text-xs opacity-80 mt-0.5">IA · Catálogo y pedidos en vivo</p>
            </div>
          </div>

          {/* Mensajes */}
          <div className="flex-1 overflow-y-auto p-3 space-y-3 text-sm">
            {messages.map((m, i) => (
              (m.role === "assistant" && !m.content) ? null : (
              <div
                key={i}
                className={`flex ${m.role === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className="max-w-[85%] rounded-2xl px-3.5 py-2.5 leading-relaxed whitespace-pre-wrap"
                  style={
                    m.role === "user"
                      ? { background: "var(--primary)", color: "var(--primary-foreground)" }
                      : { background: "var(--muted)", color: "var(--foreground)" }
                  }
                >
                  {m.content}
                </div>
              </div>
              )
            ))}
            {loading && !messages[messages.length - 1]?.content && (
              <div className="flex justify-start">
                <div
                  className="rounded-2xl px-3.5 py-2.5 flex items-center gap-1.5"
                  style={{ background: "var(--muted)" }}
                >
                  <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{estado}</span>
                </div>
              </div>
            )}
            {messages.length > 0 && messages[messages.length - 1].role === "assistant" && !loading && (
              <div className="flex flex-col gap-1.5 pt-1">
                {PREGUNTAS_RAPIDAS.map((p) => (
                  <button
                    key={p.label}
                    onClick={() => enviarPreguntaRapida(p)}
                    className="text-left text-xs px-3 py-2 rounded-xl border transition-colors hover:bg-muted"
                    style={{ borderColor: "var(--border)" }}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t flex gap-2" style={{ borderColor: "var(--border)" }}>
            <Input
              className="flex-1 text-sm h-9"
              placeholder="¿Qué mueble buscas?"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              disabled={loading}
            />
            <Button size="sm" className="h-9 w-9 p-0 flex-shrink-0" onClick={send} disabled={loading || !input.trim()}>
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </>
  );
}