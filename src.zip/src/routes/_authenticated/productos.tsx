import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Loader2, Plus, Pencil, Trash2, Image, Package, Search } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useState, useRef, useEffect } from "react";
import { toast } from "sonner";
import { uploadImage, cloudinaryUrl } from "@/lib/cloudinary";
import { CATEGORIAS, getCategoria } from "@/lib/categories";
import { listProveedores, listUbicaciones } from "@/lib/pos.functions";
import { ofertaInfo } from "@/lib/pricing";
import { EmptyState, TableSkeleton } from "@/components/states";

export const Route = createFileRoute("/_authenticated/productos")({
  validateSearch: (s: Record<string, unknown>): { q?: string } => ({
    q: typeof s.q === "string" && s.q ? s.q : undefined,
  }),
  head: () => ({ meta: [{ title: "Productos — G&M POS" }] }),
  component: ProductosPage,
});

const fmt = (n: number) =>
  new Intl.NumberFormat("es-PE", { style: "currency", currency: "PEN" }).format(n);

// Convierte un ISO string (UTC) al formato que espera <input type="datetime-local">
// respetando la hora local del navegador, para precargar el campo al editar.
const isoToLocalInput = (iso: string | null | undefined): string => {
  if (!iso) return "";
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

// ─── Tipos ───────────────────────────────────────────────────────────────────

type ProductImage = {
  url: string;
  public_id: string;
};

type ProductForm = {
  id?: string;
  nombre: string;
  descripcion: string;
  sku: string;
  precio: string;
  descuento_porcentaje: string;
  oferta_vence_el: string; // formato datetime-local ("" = sin vencimiento)
  stock: string;
  categoria: string;
  subcategoria: string;
  material_base: string;
  tipo_gestion: "manufactura" | "retail";
  proveedor_id: string;
  // Campos legacy (se mantienen sincronizados con imagenes[0])
  imagen_url: string;
  imagen_public_id: string;
  // Galería completa
  imagenes: ProductImage[];
};

const emptyForm = (): ProductForm => ({
  nombre: "", descripcion: "", sku: "", precio: "",
  descuento_porcentaje: "", oferta_vence_el: "",
  stock: "", categoria: "", subcategoria: "", material_base: "",
  tipo_gestion: "manufactura",
  proveedor_id: "",
  imagen_url: "", imagen_public_id: "",
  imagenes: [],
});

// ─── Helpers Supabase ─────────────────────────────────────────────────────────

async function listProducts() {
  const { data, error } = await supabase
    .from("products")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return data ?? [];
}

async function upsertProduct(product: any) {
  const { data, error } = await supabase
    .from("products")
    .upsert(product)
    .select()
    .single();
  if (error) throw new Error(error.message);
  return data;
}

async function deleteProduct(id: string) {
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) throw new Error(error.message);
}

// ─── Modal de formulario ──────────────────────────────────────────────────────

function ProductFormModal({
  initial, onClose,
}: {
  initial?: ProductForm | null;
  onClose: () => void;
}) {
  const qc = useQueryClient();
  const [form, setForm] = useState<ProductForm>(initial ?? emptyForm());
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const [ubicacionId, setUbicacionId] = useState<string>("");
  const [cantidadUbicacion, setCantidadUbicacion] = useState<string>("0");

  const { data: proveedoresData } = useQuery({
    queryKey: ["proveedores"],
    queryFn: listProveedores,
  });

  const { data: ubicacionesData } = useQuery({
    queryKey: ["ubicaciones"],
    queryFn: listUbicaciones,
  });

  const { data: stockUbicRows } = useQuery({
    queryKey: ["stock-ubicacion", form.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("stock_ubicacion")
        .select("ubicacion_id, cantidad")
        .eq("product_id", form.id);
      if (error) throw new Error(error.message);
      return data ?? [];
    },
    enabled: !!form.id,
  });

  // Preseleccionar Almacén Central (o la primera ubicación disponible) al cargar
  useEffect(() => {
    if (ubicacionId || !ubicacionesData?.ubicaciones?.length) return;
    const almacen = ubicacionesData.ubicaciones.find((u: any) => u.nombre === "Almacén Central");
    setUbicacionId(almacen?.id ?? ubicacionesData.ubicaciones[0].id);
  }, [ubicacionesData, ubicacionId]);

  // Al cambiar de ubicación (o cargar el stock existente), reflejar la cantidad real ahí
  useEffect(() => {
    if (!ubicacionId) return;
    const row = stockUbicRows?.find((r: any) => r.ubicacion_id === ubicacionId);
    setCantidadUbicacion(row ? String(row.cantidad) : "0");
  }, [ubicacionId, stockUbicRows]);

  const set = (k: keyof ProductForm) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
      setForm((f) => ({ ...f, [k]: e.target.value }));

  const MAX_IMAGES = 7;

  // Sube una o varias imágenes secuencialmente
  const handleMultiUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;
    // Reset input para permitir seleccionar el mismo archivo de nuevo
    e.target.value = "";

    // Calcular cuántos slots quedan
    const available = MAX_IMAGES - form.imagenes.length;
    if (available <= 0) {
      toast.error(`Máximo ${MAX_IMAGES} imágenes permitidas`);
      return;
    }
    const filesToUpload = files.slice(0, available);
    if (files.length > available) {
      toast.warning(`Solo se subirán ${available} imagen(es) — límite de ${MAX_IMAGES}`);
    }

    setUploading(true);
    try {
      for (const file of filesToUpload) {
        const result = await uploadImage(file, "muebleria/productos");
        setForm((f) => {
          const updated = [...f.imagenes, { url: result.secure_url, public_id: result.public_id }];
          return {
            ...f,
            imagenes: updated,
            // La primera imagen siempre sincroniza los campos legacy
            imagen_url: updated[0].url,
            imagen_public_id: updated[0].public_id,
          };
        });
      }
      toast.success(filesToUpload.length > 1 ? `${filesToUpload.length} imágenes subidas` : "Imagen subida correctamente");
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setUploading(false);
    }
  };

  // Elimina una imagen de la galería por índice
  const removeImage = (idx: number) => {
    setForm((f) => {
      const updated = f.imagenes.filter((_, i) => i !== idx);
      return {
        ...f,
        imagenes: updated,
        imagen_url: updated[0]?.url ?? "",
        imagen_public_id: updated[0]?.public_id ?? "",
      };
    });
  };

  // Mueve una imagen a la posición 0 (imagen principal)
  const setMainImage = (idx: number) => {
    if (idx === 0) return;
    setForm((f) => {
      const updated = [...f.imagenes];
      const [moved] = updated.splice(idx, 1);
      updated.unshift(moved);
      return {
        ...f,
        imagenes: updated,
        imagen_url: updated[0].url,
        imagen_public_id: updated[0].public_id,
      };
    });
  };

  const saveMut = useMutation({
    mutationFn: async () => {
      const savedProduct = await upsertProduct({
        ...form,
        precio: parseFloat(form.precio),
        descuento_porcentaje: form.descuento_porcentaje
          ? parseInt(form.descuento_porcentaje, 10)
          : null,
        oferta_vence_el: form.oferta_vence_el
          ? new Date(form.oferta_vence_el).toISOString()
          : null,
        // Para retail, el stock ya no se edita directo: lo calcula el trigger
        // a partir de stock_ubicacion. Para manufactura, se mantiene manual.
        stock: form.tipo_gestion === "retail" ? undefined : parseInt(form.stock, 10),
        subcategoria: form.subcategoria || null,
        material_base: form.material_base || null,
        proveedor_id: form.tipo_gestion === "retail" ? (form.proveedor_id || null) : null,
        imagenes: form.imagenes,
        ...(form.id ? { id: form.id } : {}),
      });

      if (form.tipo_gestion === "retail" && ubicacionId) {
        const { error } = await supabase.rpc("set_stock_ubicacion", {
          _ubicacion_id: ubicacionId,
          _product_id: savedProduct.id,
          _cantidad: parseInt(cantidadUbicacion, 10) || 0,
        });
        if (error) throw new Error(error.message);
      }

      return savedProduct;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["products"] });
      toast.success(form.id ? "Producto actualizado" : "Producto creado");
      onClose();
    },
    onError: (e: any) => toast.error(e.message),
  });

  return (
    <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
      <DialogHeader>
        <DialogTitle>{form.id ? "Editar producto" : "Nuevo producto"}</DialogTitle>
      </DialogHeader>
      <div className="space-y-4">

        {/* ── Galería de imágenes ── */}
        <div>
          <Label>Imágenes</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {form.imagenes.map((img, idx) => (
              <div
                key={idx}
                className="relative group w-20 h-20 cursor-pointer"
                title={idx === 0 ? "Imagen principal" : "Clic para hacer principal"}
                onClick={() => setMainImage(idx)}
              >
                <img
                  src={img.public_id
                    ? cloudinaryUrl(img.public_id, { w: 80, h: 80 })
                    : img.url}
                  alt=""
                  className={`w-20 h-20 object-cover rounded border-2 transition-all ${
                    idx === 0 ? "border-primary" : "border-transparent group-hover:border-primary/50"
                  }`}
                />
                {/* Badge principal */}
                {idx === 0 && (
                  <span className="absolute bottom-0 left-0 right-0 text-center text-[10px] bg-primary/80 text-primary-foreground rounded-b py-0.5 leading-tight">
                    Principal
                  </span>
                )}
                {/* Botón eliminar */}
                <button
                  type="button"
                  onClick={(e) => { e.stopPropagation(); removeImage(idx); }}
                  className="absolute -top-1.5 -right-1.5 bg-destructive text-destructive-foreground rounded-full w-5 h-5 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            ))}

            {/* Botón agregar más fotos — oculto al llegar al límite */}
            {form.imagenes.length < MAX_IMAGES && (
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="w-20 h-20 rounded border-2 border-dashed border-muted-foreground/30 flex flex-col items-center justify-center text-muted-foreground hover:border-primary hover:text-primary transition-colors disabled:opacity-50"
              >
                {uploading
                  ? <Loader2 className="h-5 w-5 animate-spin" />
                  : <Plus className="h-5 w-5" />}
                <span className="text-[10px] mt-1">{uploading ? "Subiendo…" : "Agregar"}</span>
              </button>
            )}

            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={handleMultiUpload}
            />
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            JPG, PNG, WEBP · Máx. {MAX_IMAGES} imágenes · Clic para hacer principal · Hover para eliminar
            {form.imagenes.length >= MAX_IMAGES && (
              <span className="text-amber-600 font-medium"> · Límite alcanzado</span>
            )}
          </p>
        </div>

        {/* ── Campos del producto ── */}
        <div>
          <Label>¿Cómo se gestiona este producto? *</Label>
          <div className="grid grid-cols-2 gap-3 mt-1">
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, tipo_gestion: "manufactura" }))}
              className={`text-left p-3 rounded-lg border transition-colors ${
                form.tipo_gestion === "manufactura" ? "border-primary bg-primary/5" : "border-border"
              }`}
            >
              <p className="text-sm font-medium">Manufactura</p>
              <p className="text-xs text-muted-foreground">Se fabrica bajo pedido (BOM, insumos, taller)</p>
            </button>
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, tipo_gestion: "retail" }))}
              className={`text-left p-3 rounded-lg border transition-colors ${
                form.tipo_gestion === "retail" ? "border-primary bg-primary/5" : "border-border"
              }`}
            >
              <p className="text-sm font-medium">Retail</p>
              <p className="text-xs text-muted-foreground">Se compra ya hecho, para reventa</p>
            </button>
          </div>
        </div>
        {form.tipo_gestion === "retail" && (
          <div>
            <Label htmlFor="proveedor_id">Proveedor</Label>
            <Select
              value={form.proveedor_id || undefined}
              onValueChange={(v) => setForm((f) => ({ ...f, proveedor_id: v }))}
            >
              <SelectTrigger id="proveedor_id">
                <SelectValue placeholder="Selecciona…" />
              </SelectTrigger>
              <SelectContent>
                {(proveedoresData?.proveedores ?? []).map((p: any) => (
                  <SelectItem key={p.id} value={p.id}>{p.nombre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground mt-1">
              Necesario para generar automáticamente una orden de compra si este producto se queda sin stock.
            </p>
          </div>
        )}
        <div>
          <Label htmlFor="nombre">Nombre *</Label>
          <Input id="nombre" required value={form.nombre} onChange={set("nombre")} />
        </div>
        <div>
          <Label htmlFor="descripcion">Descripción</Label>
          <Textarea id="descripcion" rows={3} value={form.descripcion} onChange={set("descripcion")} />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="sku">SKU</Label>
            <Input id="sku" value={form.sku} onChange={set("sku")} />
          </div>
          <div>
            <Label htmlFor="categoria">Categoría</Label>
            <Select
              value={form.categoria || undefined}
              onValueChange={(v) =>
                setForm((f) => ({ ...f, categoria: v, subcategoria: "", material_base: "" }))
              }
            >
              <SelectTrigger id="categoria">
                <SelectValue placeholder="Selecciona…" />
              </SelectTrigger>
              <SelectContent>
                {CATEGORIAS.map((c) => (
                  <SelectItem key={c.slug} value={c.slug}>{c.nombre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Subcategoría y tipo de base — dependen de la categoría elegida */}
        {(() => {
          const catCfg = getCategoria(form.categoria);
          if (!catCfg || (catCfg.subcategorias.length === 0 && !catCfg.filtroExtra)) return null;
          return (
            <div className="grid grid-cols-2 gap-3">
              {catCfg.subcategorias.length > 0 && (
                <div>
                  <Label htmlFor="subcategoria">Subcategoría</Label>
                  <Select
                    value={form.subcategoria || undefined}
                    onValueChange={(v) => setForm((f) => ({ ...f, subcategoria: v }))}
                  >
                    <SelectTrigger id="subcategoria">
                      <SelectValue placeholder="Selecciona…" />
                    </SelectTrigger>
                    <SelectContent>
                      {catCfg.subcategorias.map((s) => (
                        <SelectItem key={s.slug} value={s.slug}>{s.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              {catCfg.filtroExtra && (
                <div>
                  <Label htmlFor="material_base">{catCfg.filtroExtra.label}</Label>
                  <Select
                    value={form.material_base || undefined}
                    onValueChange={(v) => setForm((f) => ({ ...f, material_base: v }))}
                  >
                    <SelectTrigger id="material_base">
                      <SelectValue placeholder="Selecciona…" />
                    </SelectTrigger>
                    <SelectContent>
                      {catCfg.filtroExtra.opciones.map((o) => (
                        <SelectItem key={o.slug} value={o.slug}>{o.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
          );
        })()}
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="precio">Precio (S/) *</Label>
            <Input id="precio" type="number" step="0.01" min="0" required value={form.precio} onChange={set("precio")} />
          </div>
          <div>
            <Label htmlFor="descuento_porcentaje">Descuento (%)</Label>
            <Input
              id="descuento_porcentaje"
              type="number"
              min="0"
              max="90"
              placeholder="Sin oferta"
              value={form.descuento_porcentaje}
              onChange={(e) => {
                const raw = e.target.value;
                // Clamp entre 0 y 90 para que coincida con el constraint de la BD
                const clamped = raw === "" ? "" : String(Math.max(0, Math.min(90, Number(raw))));
                setForm((f) => ({ ...f, descuento_porcentaje: clamped }));
              }}
            />
          </div>
        </div>
        {!!form.descuento_porcentaje && Number(form.descuento_porcentaje) > 0 && (
          <div>
            <Label htmlFor="oferta_vence_el">La oferta vence el (opcional)</Label>
            <Input
              id="oferta_vence_el"
              type="datetime-local"
              value={form.oferta_vence_el}
              onChange={(e) => setForm((f) => ({ ...f, oferta_vence_el: e.target.value }))}
            />
            <p className="text-xs text-muted-foreground mt-1">
              Vacío = la oferta se mantiene hasta que quites el descuento manualmente.
            </p>
          </div>
        )}
        {!!form.precio && !!form.descuento_porcentaje && Number(form.descuento_porcentaje) > 0 && (
          <div className="rounded-lg bg-destructive/10 border border-destructive/20 px-3 py-2 flex items-center gap-2 text-sm flex-wrap">
            <span className="text-muted-foreground line-through">{fmt(Number(form.precio))}</span>
            <span className="font-semibold text-destructive">
              {fmt(Number(form.precio) - (Number(form.precio) * Number(form.descuento_porcentaje)) / 100)}
            </span>
            {form.oferta_vence_el && new Date(form.oferta_vence_el).getTime() <= Date.now() ? (
              <span className="text-xs text-destructive font-medium ml-auto">⚠ Esta fecha ya pasó — la oferta no se mostrará</span>
            ) : (
              <span className="text-xs text-muted-foreground ml-auto">precio final con -{form.descuento_porcentaje}%</span>
            )}
          </div>
        )}
        <div>
          {form.tipo_gestion === "manufactura" ? (
            <div>
              <Label htmlFor="stock">Stock</Label>
              <Input id="stock" type="number" min="0" value={form.stock} onChange={set("stock")} />
            </div>
          ) : (
            <div>
              <Label htmlFor="stock">Stock total</Label>
              <Input id="stock" type="number" value={form.stock || 0} disabled className="bg-muted" />
              <p className="text-[11px] text-muted-foreground mt-1">Suma de todas las ubicaciones</p>
            </div>
          )}
        </div>

        {form.tipo_gestion === "retail" && (
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label htmlFor="ubicacion_stock">Ubicación</Label>
              <Select value={ubicacionId || undefined} onValueChange={setUbicacionId}>
                <SelectTrigger id="ubicacion_stock"><SelectValue placeholder="Selecciona…" /></SelectTrigger>
                <SelectContent>
                  {(ubicacionesData?.ubicaciones ?? []).map((u: any) => (
                    <SelectItem key={u.id} value={u.id}>{u.nombre}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="cantidad_ubicacion">Cantidad en esa ubicación</Label>
              <Input
                id="cantidad_ubicacion" type="number" min="0"
                value={cantidadUbicacion}
                onChange={(e) => setCantidadUbicacion(e.target.value)}
              />
            </div>
            {stockUbicRows && stockUbicRows.length > 1 && (
              <p className="text-xs text-muted-foreground col-span-2">
                Este producto también tiene stock en otras ubicaciones — solo estás editando la seleccionada arriba.
              </p>
            )}
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button
            onClick={() => saveMut.mutate()}
            disabled={saveMut.isPending || !form.nombre || !form.precio}
          >
            {saveMut.isPending && <Loader2 className="h-4 w-4 animate-spin mr-1" />}
            Guardar
          </Button>
        </div>
      </div>
    </DialogContent>
  );
}

// ─── Página principal ─────────────────────────────────────────────────────────

function ProductosPage() {
  const { data = [], isLoading } = useQuery({ queryKey: ["products"], queryFn: listProducts });
  const qc = useQueryClient();
  const [editItem, setEditItem] = useState<ProductForm | null | undefined>(undefined);
  const { q: initialQ } = Route.useSearch();
  const [search, setSearch] = useState(initialQ ?? "");

  const delMut = useMutation({
    mutationFn: deleteProduct,
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["products"] }); toast.success("Eliminado"); },
    onError: (e: any) => toast.error(e.message),
  });

  const filtered = data.filter((p: any) =>
    !search ||
    p.nombre?.toLowerCase().includes(search.toLowerCase()) ||
    p.sku?.toLowerCase().includes(search.toLowerCase())
  );

  const enOfertaCount = data.filter((p: any) => ofertaInfo(p).activa).length;

  // Normaliza las imagenes de un producto de BD al tipo ProductImage[]
  const parseImagenes = (p: any): ProductImage[] => {
    if (Array.isArray(p.imagenes) && p.imagenes.length > 0) return p.imagenes;
    if (p.imagen_url) return [{ url: p.imagen_url, public_id: p.imagen_public_id ?? "" }];
    return [];
  };

  return (
    <div className="max-w-6xl mx-auto space-y-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-3xl font-display font-semibold">Productos</h1>
          <p className="text-muted-foreground">Catálogo propio con imágenes Cloudinary</p>
          {enOfertaCount > 0 && (
            <p className="text-xs font-medium text-destructive mt-1">
              🔥 {enOfertaCount} {enOfertaCount === 1 ? "producto en oferta" : "productos en oferta"} ahora mismo
            </p>
          )}
        </div>
        <Button onClick={() => setEditItem(null)}>
          <Plus className="h-4 w-4 mr-1" /> Nuevo producto
        </Button>
      </div>

      <Input
        placeholder="Buscar por nombre o SKU…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="max-w-xs"
      />

      <Card className="overflow-hidden">
        {isLoading ? (
          <TableSkeleton rows={6} cols={6} bare />
        ) : (
          <div className="overflow-x-auto -mx-px">
            <table className="w-full min-w-[600px] text-sm">
              <thead className="bg-muted/50 text-left">
                <tr>
                  <th className="px-4 py-3">Imágenes</th>
                  <th className="px-4 py-3">Producto</th>
                  <th className="px-4 py-3">SKU</th>
                  <th className="px-4 py-3">Categoría</th>
                  <th className="px-4 py-3 text-right">Precio</th>
                  <th className="px-4 py-3 text-center">Descuento</th>
                  <th className="px-4 py-3 text-right">Stock</th>
                  <th className="px-4 py-3"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p: any) => {
                  const imgs = parseImagenes(p);
                  const oi = ofertaInfo(p);
                  return (
                    <tr key={p.id} className="border-t hover:bg-muted/30">
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          {imgs.length > 0 ? (
                            <>
                              {/* Miniatura principal */}
                              <img
                                src={imgs[0].public_id
                                  ? cloudinaryUrl(imgs[0].public_id, { w: 48, h: 48 })
                                  : imgs[0].url}
                                alt=""
                                className="w-12 h-12 object-cover rounded"
                              />
                              {/* Contador de fotos adicionales */}
                              {imgs.length > 1 && (
                                <div className="w-12 h-12 rounded bg-muted flex items-center justify-center text-xs text-muted-foreground font-medium">
                                  +{imgs.length - 1}
                                </div>
                              )}
                            </>
                          ) : (
                            <div className="w-12 h-12 rounded bg-muted flex items-center justify-center">
                              <Image className="h-4 w-4 text-muted-foreground" />
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-medium">{p.nombre}</td>
                      <td className="px-4 py-3 text-muted-foreground font-mono">{p.sku || "—"}</td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          <Badge variant={p.tipo_gestion === "retail" ? "secondary" : "outline"}>
                            {p.tipo_gestion === "retail" ? "Retail" : "Manufactura"}
                          </Badge>
                          {p.categoria && (
                            <>
                              <Badge variant="outline">{getCategoria(p.categoria)?.nombre ?? p.categoria}</Badge>
                              {p.subcategoria && <Badge variant="secondary">{p.subcategoria}</Badge>}
                              {p.material_base && <Badge variant="secondary">{p.material_base}</Badge>}
                            </>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-right font-semibold">
                        {oi.activa ? (
                          <div className="flex flex-col items-end leading-tight">
                            <span className="text-muted-foreground line-through text-xs font-normal">{fmt(Number(p.precio))}</span>
                            <span className="text-destructive">{fmt(oi.precioFinal)}</span>
                          </div>
                        ) : (
                          fmt(Number(p.precio))
                        )}
                      </td>
                      <td className="px-4 py-3 text-center">
                        {oi.activa ? (
                          <Badge className="bg-destructive text-destructive-foreground hover:bg-destructive">
                            -{p.descuento_porcentaje}%
                          </Badge>
                        ) : p.descuento_porcentaje ? (
                          <Badge variant="outline" className="text-muted-foreground" title="El descuento sigue guardado pero ya venció">
                            Vencida
                          </Badge>
                        ) : (
                          <span className="text-muted-foreground text-xs">—</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Badge variant={Number(p.stock) > 0 ? "default" : "destructive"}>
                          {p.stock ?? 0}
                        </Badge>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => setEditItem({
                              id: p.id,
                              nombre: p.nombre,
                              descripcion: p.descripcion ?? "",
                              sku: p.sku ?? "",
                              precio: String(p.precio),
                              descuento_porcentaje: p.descuento_porcentaje != null ? String(p.descuento_porcentaje) : "",
                              oferta_vence_el: isoToLocalInput(p.oferta_vence_el),
                              stock: String(p.stock ?? 0),
                              categoria: p.categoria ?? "",
                              subcategoria: p.subcategoria ?? "",
                              material_base: p.material_base ?? "",
                              tipo_gestion: p.tipo_gestion ?? "manufactura",
                              proveedor_id: p.proveedor_id ?? "",
                              imagen_url: p.imagen_url ?? "",
                              imagen_public_id: p.imagen_public_id ?? "",
                              imagenes: parseImagenes(p),
                            })}
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => { if (confirm("¿Eliminar producto?")) delMut.mutate(p.id); }}
                          >
                            <Trash2 className="h-3.5 w-3.5 text-destructive" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={8}>
                      {data.length === 0 ? (
                        <EmptyState
                          icon={Package}
                          title="Aún no hay productos"
                          description="Crea el primero para que aparezca en la tienda y en el POS."
                        />
                      ) : (
                        <EmptyState
                          icon={Search}
                          title="Ningún producto coincide"
                          description="Prueba con otro nombre o SKU."
                          action={<Button variant="outline" size="sm" onClick={() => setSearch("")}>Limpiar búsqueda</Button>}
                        />
                      )}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      <Dialog open={editItem !== undefined} onOpenChange={(v) => !v && setEditItem(undefined)}>
        {editItem !== undefined && (
          <ProductFormModal initial={editItem} onClose={() => setEditItem(undefined)} />
        )}
      </Dialog>
    </div>
  );
}